using namespace System.Net

# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)
# Authenticating to ARM using MSI and preparing RPC valid reponse
#Write-Output  'Custom Resource Provider will trigger a request'

# Write to the Azure Functions log stream.
Write-Output  'Starting function for creating new Azure Container...'

# Interact with query parameters or the body of the request.
#($Request | ConvertTo-Json | Out-File -LiteralPath object.txt)
$getAllProperties = $Request.RawBody | ConvertFrom-Json -Depth 100

# Interact with query parameters or the body of the request.
$ContainerName     = $getAllProperties.ContainerName.toLower()
$resourceGroupName = ($ContainerName + 'crp')

Write-Output "PowerShell HTTP trigger function processed a request."
Write-Output "Requested Container Name: $ContainerName"
Write-Output "Requested Container Resource Group: $ResourceGroupName"


if ($ContainerName) {
    $getResourceGroup = Get-AzResourceGroup -Name $resourceGroupName -ErrorAction SilentlyContinue
    if (-not $getResourceGroup) {
        New-AzResourceGroup -Name $resourceGroupName `
                            -Location 'West Europe' 
    }
    ## Creating new Azure Container
    New-AzContainerGroup -ResourceGroupName $ResourceGroupName -Name $ContainerName `
                         -Image alpine -OsType Linux `
                         -Command "/bin/sh -c `"for i in ``seq 1 30``; do sleep 1; echo fSociety `$i; done`"" `
                         -RestartPolicy Never 

    $status = [HttpStatusCode]::OK
    $body = "Container has been created - Container Name: $ContainerName"
}
else {
    $status = [HttpStatusCode]::BadRequest
    $body = "Please pass a name on the query string or in the request body."
}

# Associate values to output bindings by calling 'Push-OutputBinding'.
Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
    StatusCode = $status
    Body = $body
})


